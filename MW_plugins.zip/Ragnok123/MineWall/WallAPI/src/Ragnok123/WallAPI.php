<?php

namespace Ragnok123;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\entity\Entity;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerDeathEvent;
use pocketmine\event\player\PlayerInteractEvent;
use pocketmine\event\player\PlayerJoinEvent;
use pocketmine\event\player\PlayerLoginEvent;
use pocketmine\event\player\PlayerQuitEvent;
use pocketmine\event\player\PlayerMoveEvent;
use pocketmine\item\Item;
use pocketmine\math\Vector3;
use pocketmine\Player;
use pocketmine\plugin\PluginBase;
use pocketmine\tile\Sign;
use pocketmine\tile\Chest;
use pocketmine\utils\TextFormat;
use pocketmine\utils\TextFormat as F;
use pocketmine\block\Block;
use pocketmine\utils\Config;
use pocketmine\event\player\PlayerChatEvent;
use pocketmine\level\particle\ItemBreakParticle;
use pocketmine\event\player\PlayerRespawnEvent;
use pocketmine\event\block\BlockBreakEvent;
use pocketmine\event\player\PlayerCommandPreprocessEvent;
use pocketmine\utils\Utils;


class WallAPI extends PluginBase implements Listener {
	public $drops = array();
	public $goto;
	public $timeToShotdown;
	
	public function onEnable() {
		$this->owp = $this->getServer()->getPluginManager()->getPlugin("WallPerms");
		$this->owm = $this->getServer()->getPluginManager()->getPlugin("WallMoney");
		$this->ows = $this->getServer()->getPluginManager()->getPlugin("WallShop");
		$this->owc = $this->getServer()->getPluginManager()->getPlugin("WallChat");
		$this->owk = $this->getServer()->getPluginManager()->getPlugin("WallKit");
		$this->owa = $this->getServer()->getPluginManager()->getPlugin("WallAdmin");
		$this->getServer()->getPluginManager()->registerEvents($this, $this);
		$this->getServer()->getScheduler()->scheduleRepeatingTask(new apitask($this), 2600);
		$this->getServer()->getScheduler()->scheduleRepeatingTask(new reloadtask($this), 1 * 60 * 20);
		$this->distance = 400;
		$this->owtime = 60;
		$this->timeToShotdown = 120 * 60;
	}
	
	public function reloadTime() {
		$this->timeToShotdown -= 60;
		foreach ($this->getServer()->getOnlinePlayers() as $p) {
			$p->sendMessage(F::YELLOW. "[MineWall]". F::GOLD. " Restart serveru za " .F::GREEN. $this->timeToShotdown / 60 . F::GOLD. " minut.");
		}
		$this->getServer()->getLogger()->info(F::YELLOW. "[MineWall]" .F::GOLD. " Do restartu zbyva " .F::GREEN. $this->timeToShotdown / 60 . F::GOLD. " minut.");
		
		if($this->timeToShotdown <= 1) {
			$this->getServer()->shutdown();
		}
	}
	
	public function joinMsg(PlayerJoinEvent $e) {
		$e->setJoinMessage(null);
		foreach ($this->getServer()->getOnlinePlayers() as $p) {
			$p->sendTip(F::DARK_AQUA. $e->getPlayer()->getName(). F::GOLD. " prisel k nam");
		}
	}
	
	public function quitMsg(PlayerQuitEvent $e) {
		$e->setQuitMessage(null);
		foreach ($this->getServer()->getOnlinePlayers() as $p) {
			$p->sendTip(F::DARK_AQUA. $e->getPlayer()->getName(). F::GOLD. " odesel od nas");
		}
	}
	
	public function BreakMoney(BlockBreakEvent $e) {
		$player = $e->getPlayer();
		$this->owm->addMoney($player->getName(), 3);
		$player->sendTip(F::YELLOW. "+1 koruna");
	}
	
	public function broadcastMsg() {
		$rand = mt_rand(1, 5);
		switch($rand) {
			case 1:
			$msg = F::GOLD. " Kup si VIP, Premium: " .F::AQUA. "Jeste neni dostupne";
			break;
			case 2:
			$msg = F::GOLD. " Chces litat, velky inventar, vyhazovani veci rychleji? Takovou moznost ma jen VIP!\n" .F::GREEN. "Kup VIP: " .F::AQUA. "jeste neni dostupne";
		    break;
			case 3:
			$msg = F::GOLD. " Chcete creative? Mit nekonecno bloku? Mit 3x vetsi inventar atf?\n" .F::GOLD. "Takze musite byt Premium!\n" .F::GREEN. "Kup si Premium: " .F::AQUA. "Neni dostupne";
		    break;
			case 4:
			$msg = F::GOLD. " Chcete mit vlast nad ostatnimi?\n" .F::GOLD. "Takze helper je to, cim musite bit!\n" .F::GREEN. "Sledujte nas na strance FB: " .F::AQUA. "MineWall";
		    break;
			case 5:
			$msg = F::GOLD. " Chces byt vic, nez hrac? Kup si VIP, Premium a donat\n" .F::GREEN. "Kup si to pres sms:" .F::AQUA. "Neni dostupne";
		    break;
		}
		
		foreach ($this->getServer()->getOnlinePlayers() as $p) {
			$p->sendMessage(F::YELLOW. "[MineWall]". F::RESET. $msg);
		}
		$this->getServer()->getLogger()->info(F::YELLOW. "[MineWall]". F::RESET. $msg);
	}
	
	public function setPrefixTag($player) {
		$group = $this->owp->getGroup($player->getName());
		if($group == "user") {
			$player->setNameTag(F::GRAY. "user " .F::DARK_AQUA. $player->getName());
		}
		if($group == "vip") {
			$player->setNameTag(F::BLUE. F::BOLD. "vip " .F::DARK_AQUA. $player->getName());
		}
		if($group == "premium") {
			$player->setNameTag(F::LIGHT_PURPLE. F::BOLD. "premium " .F::DARK_AQUA. $player->getName());
		}
		if($group == "helper") {
			$player->setNameTag(F::DARK_GREEN. F::BOLD. "helper " .F::DARK_AQUA. $player->getName());
		}
		if($group == "admin") {
			$player->setNameTag(F::RED. F::BOLD. "admin " .F::DARK_AQUA. $player->getName());
		}
		if($group == "youtube") {
			$player->setNameTag(F::BOLD. F::WHITE. "You" .F::RED. "Tube " .F::DARK_AQUA. $player->getName());
		}
	}
	
	public function why($entityName){
 		if(!is_file($this->getDataFolder()."players/".$entityName.".yml")){
			$this->createData($entityName);
		}
	}
	
	public function createData($entityName) {
        if(!is_file($this->getDataFolder()."players/".$entityName.".yml")){
            @mkdir($this->getDataFolder() . "players/");
		    $data = new Config($this->getDataFolder() . "players/".$entityName.".yml", Config::YAML);
		    $data->set("x", null);
			$data->set("y", null);
			$data->set("z", null);
		    $data->save();
		}
	}
	
	public function getHomeX($entityName) {
		$this->why($entityName);
        $sFile = (new Config($this->getDataFolder() . "players/".$entityName.".yml", Config::YAML))->getAll();
        return $sFile["x"];
	}
	
	public function getHomeY($entityName) {
		$this->why($entityName);
        $sFile = (new Config($this->getDataFolder() . "players/".$entityName.".yml", Config::YAML))->getAll();
        return $sFile["y"];
	}
	
	public function getHomeZ($entityName) {
		$this->why($entityName);
        $sFile = (new Config($this->getDataFolder() . "players/".$entityName.".yml", Config::YAML))->getAll();
        return $sFile["z"];
	}
	
	public function setHome($entityName, $x, $y, $z) {
		$this->why($entityName);
        $sFile = (new Config($this->getDataFolder() . "players/".$entityName.".yml", Config::YAML))->getAll();
        $sFile["x"] = (int) $x;
		$sFile["y"] = (int) $y;
		$sFile["z"] = (int) $z;
      	$fFile = new Config($this->getDataFolder() . "players/".$entityName.".yml", Config::YAML);
	    $fFile->setAll($sFile);
        $fFile->save();
	}
	
	public function JoinDonat(PlayerJoinEvent $e) {
		$entity = $e->getPlayer();
		$this->why($entity->getName());
		$this->gotoname[$entity->getName()] = null;
		$this->goto[$entity->getName()] = false;
		$this->setPrefixTag($entity);
		if($this->owp->getGroup($entity->getName()) == "vip") {
			$entity->getInventory()->setSize(70);
		} elseif($this->owp->getGroup($entity->getName()) == "premium") {
			$entity->getInventory()->setSize(120);
		}
	}
	
	public function WorldBorder(PlayerMoveEvent $e) {
		$entity = $e->getPlayer();
		$v = new Vector3($entity->getLevel()->getSpawnLocation()->getX(), $entity->getPosition()->getY(), $entity->getLevel()->getSpawnLocation()->getZ());
		if($this->owp->getGroup($entity->getName()) == "user") {
			if(floor($entity->distance($v)) >= $this->distance) {
				$e->setCancelled();
				$entity->sendTip(F::YELLOW. "[WallAPI]" .F::GOLD. " Nekonecny svet? Kup si  " .F::GREEN. "vip" .F::GOLD. "!");
			}
		}
	}
	
    public function WhoDamager(EntityDamageEvent $e) {
        $entity = $e->getEntity();
		$entity = $e->getEntity();
		$level = $this->getServer()->getDefaultLevel();
        if ($entity instanceof Player) {
            if ($e instanceof EntityDamageByEntityEvent) {
                $damager = $e->getDamager()->getPlayer();
                $cause = $e->getEntity()->getPlayer()->getName();
                if ($e->getDamager() instanceof Player) {
					if($level->getTime() < 16500) {
						if(!($damager->isOp())) {
							$e->setCancelled();
							$damager->sendTip(F::RED. "Nemuzete se mlatit dnem");
						}
					}
                    $v = new Vector3($entity->getLevel()->getSpawnLocation()->getX(),$entity->getPosition()->getY(),$entity->getLevel()->getSpawnLocation()->getZ());
                    $r = $this->getServer()->getSpawnRadius();
                    if(($entity instanceof Player) && ($entity->getPosition()->distance($v) <= $r)) {
						if(!($damager->isOp())) {
							$e->setCancelled();
							$damager->sendTip(F::RED. "Nemuzete se mlatit na spawnu!");
						}
					}
				}
			}
		}
	}
	
    public function onCommand(CommandSender $entity, Command $cmd, $label, array $args) {
		$level = $this->getServer()->getDefaultLevel();
		$x = $this->getServer()->getDefaultLevel()->getSafeSpawn()->getX();
        $y = $this->getServer()->getDefaultLevel()->getSafeSpawn()->getY();
        $z = $this->getServer()->getDefaultLevel()->getSafeSpawn()->getZ();
		$group = $this->owp->getGroup($entity->getName());
        switch ($cmd->getName()) {


            case "spawn":
			if($entity Instanceof Player) {
	            $entity->teleport(new Vector3($x, $y, $z, $level));
				$entity->sendMessage(F::GOLD. "Уважаемый " .F::DARK_AQUA. $entity->getName(). F::GOLD. ", Jste na spawnu.");
			} else {
				$entity->sendMessage(F::YELLOW. "[WallAPI]" .F::GOLD. " Prikaz jde jen od hrace.");
			}
			break;
			case "sethome":
			if($entity Instanceof Player) {
				$this->setHome($entity->getName(), $entity->getX(), $entity->getY(), $entity->getZ());
				$entity->sendMessage(F::YELLOW. "[WallAPI]" .F::GOLD. " Nyni mate teleport k domku.");
			} else {
				$entity->sendMessage(F::YELLOW. "[WallAPI]" .F::GOLD. " Prikaz jde jen od hrace.");
			}
			break;
			case "home":
			if($entity Instanceof Player) {
				if($this->getHomeX($entity->getName()) != null && $this->getHomeY($entity->getName()) != null && $this->getHomeZ($entity->getName()) != null) {
					$entity->teleport(new Vector3($this->getHomeX($entity->getName()), $this->getHomeY($entity->getName()), $this->getHomeZ($entity->getName()), $level));
					$entity->sendMessage(F::YELLOW. "[WallAPI]" .F::GOLD. " Domek.");
				} else {
					$entity->sendMessage(F::YELLOW. "[WallAPI]" .F::GOLD. " Jeste nemate domek.");
				}
			} else {
				$entity->sendMessage(F::YELLOW. "[WallAPI]" .F::GOLD. "Prikaz jde jen od hrace.");
			}
			break;
			case "tpall":
			if($entity Instanceof Player) {
				if($this->owp->getGroup($entity->getName()) == "helper" || $this->owp->getGroup($entity->getName()) == "admin") {
					foreach ($this->getServer()->getOnlinePlayers() as $p) {
						$p->teleport(new Vector3($entity->getX(), $entity->getY(), $entity->getZ()));
						$this->getServer()->getLogger()->info(F::YELLOW. "[WallAPI]" .F::GREEN. $entity->getName(). F::GOLD. " TP vsech k sobe/nekomu.");
					}
				} else {
					$entity->sendMessage(F::YELLOW. "[WallAPI]" .F::GOLD. " Nemate permisse");
				}
			} else {
				$entity->sendMessage(F::YELLOW. "[WallAPI]" .F::GOLD. " Prikaz jde jen od hrace.");
			}
			break;
			case "clear":
			if($entity Instanceof Player) {
				$entity->getInventory()->clearAll();
				$entity->sendMessage(F::GOLD. "Vazeny/a " .F::DARK_AQUA. $entity->getName(). F::GOLD. ", vas inventar je ocisteny");
			} else {
				$entity->sendMessage(F::YELLOW. "[WallAPI]" .F::GOLD. " Prikaz jde jen od hrace.");
			}
			break;
			case "gm":
			if($entity Instanceof Player) {
				if($this->owp->getGroup($entity->getName()) != "user" && $this->owp->getGroup($entity->getName()) != "vip") {
					if(isset($args[0])) {
						if(is_numeric($args[0])) {
							$entity->setGamemode($args[0]);
							$entity->sendMessage(F::YELLOW. "[WallAPI]" .F::GOLD. " Zmenili jste gamemode.");
						} else {
							$entity->sendMessage(F::YELLOW. "[WallAPI]" .F::GOLD. " Gamemode 1|2|3");
						}
					} else {
						$entity->sendMessage(F::YELLOW. "[WallAPI]" .F::GOLD. " Napiste gamemode.");
					}
				} else {
					$entity->sendMessage(F::YELLOW. "[WallAPI]" .F::GOLD. " Musite mit aspon Premium");
				}
			} else {
				$entity->sendMessage(F::YELLOW. "[WallAPI]" .F::GOLD. " Prikaz jde jen od hrace.");
			}
			break;
			case "fly":
			if($entity Instanceof Player) {
				if($this->owp->getGroup($entity->getName()) != "user") {
					if(isset($args[0])) {
						if($args[0] == "on") {
							$entity->setAllowFlight(true);
							$entity->sendMessage(F::YELLOW. "[WallAPI]" .F::GOLD. " Nyni muzete litat");
						}
						if($args[0] == "off") {
							$entity->setAllowFlight(false);
							$entity->sendMessage(F::YELLOW. "[WallAPI]" .F::GOLD. " Nyni muzete chodiz.");
						}
					} else {
						$entity->sendMessage(F::YELLOW. "[WallAPI]" .F::GOLD. " /fly on|off.");
					}
				} else {
					$entity->sendMessage(F::YELLOW. "[WallAPI]" .F::GOLD. " Musite byt aspon VIP.");
				}
			}
			break;
			case "setprefix":
			if($entity Instanceof Player) {
				if($this->owp->getGroup($entity->getName()) != "user") {
					if(isset($args[0])) {
						$this->owc->setPrefix($entity->getName(), $args[0]);
						$entity->sendMessage(F::YELLOW. "[WallAPI]" .F::GOLD. " Uspesne jste nastavili prefix " .F::GREEN. $args[0]) .F::GOLD. ".";
						
					} else {
						$entity->sendMessage(F::YELLOW. "[WallAPI]" .F::GOLD. " Napiste prefix.");
					}
				} else {
					$entity->sendMessage(F::YELLOW. "[WallAPI]" .F::GOLD. " Musite byt aspon VIP.");
				}
			}
			break;
			case "kit":
			if($entity Instanceof Player) {
				$this->owk->giveKit($entity);
			}
			break;
			case "sleep":
			if($group != "user") {
				$entity->sleepOn(new Vector3($entity->getX(), $entity->getY(), $entity->getZ()));
				$entity->sendMessage(F::YELLOW. "[WallAPI]" .F::GOLD. " Dobrou noc!");
			} else {
				$entity->sendMessage(F::YELLOW. "[WallAPI]" .F::GOLD. " Musite byt aspon VIP!");
			}
			break;
			case "money":
			$entity->sendMessage(F::YELLOW. "[WallAPI]" .F::GOLD. " Korun: " .F::GREEN .$this->owm->getMoney($entity->getName()));
			break;
			case "goto":
			if(isset($args[0])) {
				if($this->getServer()->getPlayer($args[0]) Instanceof Player) {
					$this->gotoname[$entity->getName()] = $args[0];
					$this->goto[$entity->getName()] = true;
				} else {
					$entity->sendMessage(F::YELLOW. "[WallAPI]" .F::GOLD. " Tento hrac je offline");
				}
			} else {
				$entity->sendMessage(F::YELLOW. "[WallAPI]" .F::GOLD. " Napiste nick hrace.");
			}
			break;
			case "shop":
			if($entity Instanceof Player) {
				if(isset($args[0])) {
					if(isset($args[1])) {
						$this->ows->shopping($entity, $args[0], $args[1]);
					} else {
						$entity->sendMessage(F::YELLOW. "[WallAPI]" .F::GOLD. " Napiste pocet.");
					}
				} else {
					$entity->sendMessage(F::YELLOW. "[WallAPI]" .F::GOLD. " Napiste ID predmetu.");
				}
			}
			break;
			case "ap":
			if($entity->isOp() && $entity Instanceof Player) {
				if(isset($args[0])) {
					if(isset($args[1])) {
						$this->ows->createPrice($args[0], $args[1]);
						$entity->sendMessage(F::YELLOW. "[WallAPI]" .F::GOLD. " Nastavili jste predmetu s ID" .F::DARK_GREEN. $args[0]. F::GOLD. " cenu " .F::DARK_GREEN. $args[1]);
					} else {
						$entity->sendMessage(F::YELLOW. "[WallAPI]" .F::GOLD. " Napiste cenu.");
					}
				} else {
					$entity->sendMessage(F::YELLOW. "[WallAPI]" .F::GOLD. " Napiste ID predmetu.");
				}
			}
		}
	}
	
	public function moveGoto(PlayerMoveEvent $e) {
		$entity = $e->getPlayer();
		if($this->goto[$entity->getName()]) {
			if(isset($this->gotoname[$entity->getName()])) {
				$entity->sendTip(F::YELLOW. "[WallAPI]" .F::GOLD. " Distance hrace " .F::DARK_GREEN. $this->gotoname[$entity->getName()]. F::GOLD. ": " .F::GREEN. floor($entity->distance(new Vector3($this->getServer()->getPlayer($this->gotoname[$entity->getName()])->getX(), $this->getServer()->getPlayer($this->gotoname[$entity->getName()])->getY(), $this->getServer()->getPlayer($this->gotoname[$entity->getName()])->getZ()))));
			}
			if(floor($entity->distance(new Vector3($this->getServer()->getPlayer($this->gotoname[$entity->getName()])->getX(), $this->getServer()->getPlayer($this->gotoname[$entity->getName()])->getY(), $this->getServer()->getPlayer($this->gotoname[$entity->getName()])->getZ()))) <= 10) {
				$this->goto[$entity->getName()] = false;
				$this->gotoname[$entity->getName()] = null;
			}
		}
		if($this->goto[$entity->getName()]) {
			if(!($this->getServer()->getPlayer($this->gotoname[$entity->getName()]) Instanceof Player)) {
				$this->goto[$entity->getName()] = false;
				$this->gotoname[$entity->getName()] = null;
			}
		}
	}
	
	public function cmd(PlayerCommandPreprocessEvent $e) {
		$entity = $e->getPlayer();
		$msg = $e->getMessage();
		$group = $this->owp->getGroup($entity->getName());
		if($msg{0} == "/" && $msg{1} == "h" && $msg{2} == "e" && $msg{3} == "l" && $msg{4} == "p") {
			$e->setCancelled();
			if($group == "user") {
				$entity->sendMessage(F::YELLOW. "-------------------");
				$entity->sendMessage(F::YELLOW. "- /spawn" .F::DARK_GREEN. " - Teleportuje na Spawn");
				$entity->sendMessage(F::YELLOW. "- /money" .F::DARK_GREEN. " - Vase penize");
				$entity->sendMessage(F::YELLOW. "- /sethome" .F::DARK_GREEN. " - Nastavit domek");
				$entity->sendMessage(F::YELLOW. "- /home" .F::DARK_GREEN. " - Teleport domu");
				$entity->sendMessage(F::YELLOW. "- /kit" .F::DARK_GREEN. " - Dostat kit");
				$entity->sendMessage(F::YELLOW. "- /rg" .F::DARK_GREEN. " -Neni k dispozici ");
				$entity->sendMessage(F::YELLOW. "- /goto" .F::DARK_GREEN. " - найти игрока");
				$entity->sendMessage(F::YELLOW. "- /shop" .F::DARK_GREEN. " - купить предмет");
				$entity->sendMessage(F::YELLOW. "-------------------");
			} elseif($group == "vip" || $group == "premium" || $group == "youtube") {
				$entity->sendMessage(F::YELLOW. "-------------------");
				$entity->sendMessage(F::YELLOW. "- /spawn" .F::DARK_GREEN. " - телепортация на спавн");
				$entity->sendMessage(F::YELLOW. "- /money" .F::DARK_GREEN. " - проверить деньги");
				$entity->sendMessage(F::YELLOW. "- /sethome" .F::DARK_GREEN. " - установить точку дома");
				$entity->sendMessage(F::YELLOW. "- /home" .F::DARK_GREEN. " - телепортироваться домой");
				$entity->sendMessage(F::YELLOW. "- /setprefix" .F::DARK_GREEN. " - установить префикс");
				$entity->sendMessage(F::YELLOW. "- /fly" .F::DARK_GREEN. " - включить\отключить полет");
				$entity->sendMessage(F::YELLOW. "- /gm" .F::DARK_GREEN. " - смена игрового режима");
				$entity->sendMessage(F::YELLOW. "- /sleep" .F::DARK_GREEN. " - лечь спать");
				$entity->sendMessage(F::YELLOW. "- /kit" .F::DARK_GREEN. " - получить начальный кит");
				$entity->sendMessage(F::YELLOW. "- /owguard" .F::DARK_GREEN. " - приват");
				$entity->sendMessage(F::YELLOW. "- /goto" .F::DARK_GREEN. " - найти игрока");
				$entity->sendMessage(F::YELLOW. "- /shop" .F::DARK_GREEN. " - купить предмет");
				$entity->sendMessage(F::YELLOW. "-------------------");
			} elseif($group == "helper" || $group == "admin") {
				$entity->sendMessage(F::YELLOW. "-------------------");
				$entity->sendMessage(F::YELLOW. "- /spawn" .F::DARK_GREEN. " - телепортация на спавн");
				$entity->sendMessage(F::YELLOW. "- /money" .F::DARK_GREEN. " - проверить деньги");
				$entity->sendMessage(F::YELLOW. "- /sethome" .F::DARK_GREEN. " - установить точку дома");
				$entity->sendMessage(F::YELLOW. "- /home" .F::DARK_GREEN. " - телепортироваться домой");
				$entity->sendMessage(F::YELLOW. "- /setprefix" .F::DARK_GREEN. " - установить префикс");
				$entity->sendMessage(F::YELLOW. "- /fly" .F::DARK_GREEN. " - включить\отключить полет");
				$entity->sendMessage(F::YELLOW. "- /gm" .F::DARK_GREEN. " - смена игрового режима");
				$entity->sendMessage(F::YELLOW. "- /sleep" .F::DARK_GREEN. " - лечь спать");
				$entity->sendMessage(F::YELLOW. "- /kit" .F::DARK_GREEN. " - получить начальный кит");
				$entity->sendMessage(F::YELLOW. "- /owguard" .F::DARK_GREEN. " - приват");
				$entity->sendMessage(F::YELLOW. "- /owban" .F::DARK_GREEN. " - забанить игрока");
				$entity->sendMessage(F::YELLOW. "- /owkick" .F::DARK_GREEN. " - кикнуть игрока");
				$entity->sendMessage(F::YELLOW. "- /tpall" .F::DARK_GREEN. " - телепортировать всех к себе");
				$entity->sendMessage(F::YELLOW. "- /goto" .F::DARK_GREEN. " - найти игрока");
				$entity->sendMessage(F::YELLOW. "- /shop" .F::DARK_GREEN. " - купить предмет");
				$entity->sendMessage(F::YELLOW. "-------------------");
			}
		}
		if($msg{0} == "/" && $msg{1} == "m" && $msg{2} == "e") {
			$e->setCancelled();
			$entity->sendMessage(F::YELLOW. "Nemuzes to napsat :)");
		}
	}
	
    public function PlayerDeath(PlayerDeathEvent $e){
        $entity = $e->getEntity();
		if($this->owp->getGroup($entity->getName() != "user")) {
			$this->drops[$entity->getName()][1] = $entity->getInventory()->getArmorContents();
			$this->drops[$entity->getName()][0] = $entity->getInventory()->getContents();
			$e->setDrops(array());
		}
    }
	
	public function PlayerRespawn(PlayerRespawnEvent $e){
        $entity = $e->getPlayer();
		if($this->owp->getGroup($entity->getName()) != "user") {
			if (isset($this->drops[$entity->getName()])) {
				$entity->getInventory()->setContents($this->drops[$entity->getName()][0]);
				$entity->getInventory()->setArmorContents($this->drops[$entity->getName()][1]);
				unset($this->drops[$entity->getName()]);
				$entity->sendMessage(F::YELLOW. "[WallAPI]" .F::GOLD. " Chcipli jste. Vas inventar je v poradku.");
			}
		}
    }
	
}