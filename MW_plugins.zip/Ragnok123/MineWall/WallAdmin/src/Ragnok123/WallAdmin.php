<?php

namespace Ragnok123;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\entity\Entity;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerDeathEvent;
use pocketmine\event\player\PlayerInteractEvent;
use pocketmine\event\player\PlayerJoinEvent;
use pocketmine\event\player\PlayerLoginEvent;
use pocketmine\event\player\PlayerMoveEvent;
use pocketmine\event\player\PlayerQuitEvent;
use pocketmine\item\Item;
use pocketmine\math\Vector3;
use pocketmine\Player;
use pocketmine\plugin\PluginBase;
use pocketmine\tile\Sign;
use pocketmine\utils\TextFormat;
use pocketmine\utils\TextFormat as F;
use pocketmine\block\Block;
use pocketmine\utils\Config;
use pocketmine\event\player\PlayerChatEvent;
use pocketmine\level\particle\ItemBreakParticle;
use pocketmine\event\player\PlayerRespawnEvent;
use pocketmine\event\block\BlockBreakEvent;
use pocketmine\event\player\PlayerCommandPreprocessEvent;
use pocketmine\event\player\PlayerPreLoginEvent;

class WallAdmin extends PluginBase implements Listener {
	public $token;
	
	public function onEnable() {
		$this->owp = $this->getServer()->getPluginManager()->getPlugin("WallPerms");
		$this->getServer()->getPluginManager()->registerEvents($this, $this);
		$this->mysqli = new \mysqli("82.208.17.16", "195435_mysql_db", "Stargatewars1488", "195435_mysql_db");
	}
	
	public function onPlayerPreLogin(PlayerPreLoginEvent $event){
		$player = $event->getPlayer();
		if($this->getBanned($player->getName())) {
			$event->setCancelled(true);
			$player->close("", F::GOLD. "Mate ban.");
		}
	}
	
	public function kick($player, $kicker, $reason) {
		if($kicker Instanceof Player) {
			if($this->getServer()->getPlayer($player) Instanceof Player) {
				foreach ($this->getServer()->getOnlinePlayers() as $p) {
					$p->sendMessage(F::YELLOW. "[WallAdmin] " .F::GREEN. $kicker->getName(). F::GOLD. " kicknul hrace " .F::GREEN. $player. F::GOLD. " za  " .F::DARK_GREEN. $reason);
				}
				$this->getLogger()->info(F::YELLOW. "[OWAdmin] " .F::GREEN. $kicker->getName(). F::GOLD. " кикнул игрока " .F::GREEN. $player. F::GOLD. " за " .F::DARK_GREEN. $reason);
				$this->getServer()->getPlayer($player)->kick(F::GOLD. $reason);
			} else {
				$kicker->sendMessage(F::YELLOW. "[WalllAdmin]" .F::GOLD. " Hrac tady neni.");
			}
		} else {
			if($this->getServer()->getPlayer($player) Instanceof Player) {
				foreach ($this->getServer()->getOnlinePlayers() as $p) {
					$p->sendMessage(F::YELLOW. "[Walldmin]" .F::GREEN. " CONSOLE". F::GOLD. " kicknul hrace " .F::GREEN. $player. F::GOLD. " za " .F::DARK_GREEN. $reason);
				}
				$this->getLogger()->info(F::YELLOW. "[WallAdmin]" .F::GREEN. " CONSOLE". F::GOLD. " kicknul hrace " .F::GREEN. $player. F::GOLD. " за " .F::DARK_GREEN. $reason);
				$this->getServer()->getPlayer($player)->kick(F::GOLD. $reason);
			} else {
				$kicker->sendMessage(F::YELLOW. "[WallAdmin]" .F::GOLD. " Hrac neni online.");
			}
		}
	}
	
	public function addban($username, $reason, $banner) {
		$username = strtolower($username);
		if($this->getAcc($username)) {
			if(!($this->getBanned($username))) {
				$this->mysqli->query('SET CHARACTER SET utf8');
				$this->mysqli->query("INSERT INTO `ban` (`id`, `nickname`, `reason`) VALUES (NULL, '".$username."', '".$reason."')");
				$this->banvk($username, $reason);
				if($this->getServer()->getPlayer($username) Instanceof Player) {
					$this->getServer()->getPlayer($username)->close("", F::GOLD. "Máte ban.");
				}
				$banner->sendMessage(F::YELLOW. "[WallAdmin]" .F::GOLD. " Hrav " .F::GREEN. $username .F::GOLD. " ma ban za " .F::GREEN. $reason. F::GOLD. ".");
				$this->sendUsers(F::YELLOW. "[WallAdmin] " .F::GREEN. $banner->getName() .F::GOLD. " dal ban hracovi " .F::GREEN. $username. F::GOLD. " za " .F::GREEN. $reason. F::GOLD. ".");
			} else {
				$banner->sendMessage(F::YELLOW. "[WallAdmin]" .F::GOLD. " Hrac ma ban.");
			}
		} else {
			$banner->sendMessage(F::YELLOW. "[WallAdmin]" .F::GOLD. " Tento hrac neni.");
		}
	}
	
	public function sendUsers($text) {
		foreach ($this->getServer()->getOnlinePlayers() as $p) {
			$p->sendMessage($text);
		}
	}
	
	public function removeBan($username, $banner) {
		$username = strtolower($username);
		if($this->getBanned($username)) {
			$this->mysqli->query("DELETE FROM `ban` WHERE `nickname` = '".$username."'");
			$this->unbanVk($username);
			$banner->sendMessage(F::YELLOW. "[WallAdmin]" .F::GOLD. " Hrac " .F::GREEN. $username. F::GOLD. " uz nema ban.");
		} else {
			$banner->sendMessage(F::YELLOW. "[WallAdmin]" .F::GOLD. " Hrac neni v banlist.");
		}
	}
	
	public function getBanned($username) {
	    $username = strtolower($username);
		$result = $this->mysqli->query("SELECT * FROM `ban` WHERE `nickname` = '".$username."'");
        $user = mysqli_fetch_assoc($result);
        if($user) {
	        return true;
        } else {
	        return false;
        }
	}
	
	public function getAcc($username) {
	    $username = strtolower($username);
		$result = $this->mysqli->query("SELECT * FROM `acc` WHERE `nickname` = '".$username."'");
        $user = mysqli_fetch_assoc($result);
        if($user) {
	        return true;
        } else {
	        return false;
        }
	}
	
	public function banvk($username, $reason) {
		$username = strtolower($username);
        $result = $this->mysqli->query("SELECT * FROM `acc` WHERE `nickname` = '".$username."'");
		$data = $result->fetch_assoc();
		$result->free();
		$vk = $data["vk"];
	    $token = "9cbda38e2110324e7f94c1b7720be6b9f5588492a0fbc839276faaaa47d1c478f99d49fdc1ab811e11c54";
        $curlObject = curl_init("https://api.vk.com/method/groups.banUser?access_token=" .$token. "&user_id=" .$vk. "&group_id=73298513&comment=" .rawurlencode($reason));
       	curl_setopt($curlObject, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($curlObject, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($curlObject, CURLOPT_RETURNTRANSFER, true);
        @curl_exec($curlObject);
        @curl_close($curlObject);
	}
	
	public function unbanVk($username) {
		$username = strtolower($username);
        $result = $this->mysqli->query("SELECT * FROM `acc` WHERE `nickname` = '".$username."'");
		$data = $result->fetch_assoc();
		$result->free();
		$vk = $data["vk"];
		$token = "9cbda38e2110324e7f94c1b7720be6b9f5588492a0fbc839276faaaa47d1c478f99d49fdc1ab811e11c54";
        $curlObject = curl_init("https://api.vk.com/method/groups.unbanUser?access_token=" .$token. "&user_id=" .$vk. "&group_id=73298513");
        curl_setopt($curlObject, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($curlObject, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($curlObject, CURLOPT_RETURNTRANSFER, true);
        @curl_exec($curlObject);
        @curl_close($curlObject);
	}
	
    public function onCommand(CommandSender $entity, Command $cmd, $label, array $args) {
		$group = $this->owp->getGroup($entity->getName());
        switch ($cmd->getName()) {
			case "wallkick":
			if($entity Instanceof Player) {
				if(isset($args[0])) {
					if(isset($args[1])) {
						if($group == "helper" || $group == "admin") {
							$this->kick($args[0], $entity, $args[1]);
						}
					} else {
						$entity->sendMessage(F::YELLOW. "[WallApi]". F::GOLD. " Napiste duvod kicknuti.");
					}
				} else {
					$entity->sendMessage(F::YELLOW. "[WallApi]". F::GOLD. " Napiste nick hrace.");
				}
			} else {
				if(isset($args[0])) {
					if(isset($args[1])) {
						$this->owa->kick($args[0], $entity, $args[1]);
					} else {
						$entity->sendMessage(F::YELLOW. "[WallApi]". F::GOLD. " Napiste duvod kicknuti.");
					}
				} else {
					$entity->sendMessage(F::YELLOW. "[WallApi]". F::GOLD. " Napiste nick hrace.");
				}
			}
			break;
			case "wallban":
			if($entity Instanceof Player) {
				if(isset($args[0])) {
					if(isset($args[1])) {
						if($group == "helper" || $group == "admin") {
							$this->addban($args[0], $args[1], $entity);
						}
					} else {
						$entity->sendMessage(F::YELLOW. "[WallApi]". F::GOLD. " Napiste duvod banu.");
					}
				} else {
					$entity->sendMessage(F::YELLOW. "[WLlApi]". F::GOLD. " Napiste nick hrace.");
				}
			} else {
				if(isset($args[0])) {
					if(isset($args[1])) {
						$this->addban($args[0], $args[1], $entity);
					} else {
						$entity->sendMessage(F::YELLOW. "[WallApi]". F::GOLD. " Napiste duvod banu.");
					}
				} else {
					$entity->sendMessage(F::YELLOW. "[WallApi]". F::GOLD. " Napiste nick hrace.");
				}
			}
			break;
			case "wallpardon":
			if($entity Instanceof Player) {
				if(isset($args[0])) {
					if($group == "helper" || $group == "admin") {
					    $this->removeBan($args[0], $entity);
					}
				} else {
					$entity->sendMessage(F::YELLOW. "[WallApi]". F::GOLD. " Napiste nick hrace.");
				}
			} else {
				if(isset($args[0])) {
					$this->removeBan($args[0], $entity);
				} else {
					$entity->sendMessage(F::YELLOW. "[WallApi]". F::GOLD. " Napiste nick hrace.");
				}
			}
			break;
		}
	}
	
}